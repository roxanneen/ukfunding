import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Static export for Vercel / static hosting
  // Uncomment when ready to deploy:
  // output: 'export',
};

export default nextConfig;
