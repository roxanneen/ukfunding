// src/data/index.ts — Re-export all data for convenient imports
export { schemes } from './schemes';
export { regions } from './regions';
export { sectors } from './sectors';
export { ariaPrograms } from './ariaPrograms';
export { privateFirms } from './privateFirms';
export type * from './types';
